import { Alert } from './Alert';
import { StateCard } from './StateCard';

type PageFeedbackProps = {
  /** Errores a mostrar; los vacíos y repetidos se ignoran (por eso se puede pasar un error de carga que aún no existe). */
  errors: string[];
  success?: string;
  loadingDetail?: boolean;
};

/** Mensajes de una página: errores, éxito y "Cargando detalle...". */
export function PageFeedback({ errors, success = '', loadingDetail = false }: PageFeedbackProps) {
  return (
    <>
      {[...new Set(errors)].filter(Boolean).map((mensaje) => (
        <Alert key={mensaje} kind="error">
          {mensaje}
        </Alert>
      ))}
      {success && <Alert kind="success">{success}</Alert>}
      {loadingDetail && <StateCard>Cargando detalle...</StateCard>}
    </>
  );
}
