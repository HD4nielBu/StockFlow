import { Button } from './Button';

type ActionsCellProps = {
  /** Texto que identifica la fila para lectores de pantalla: "Editar {etiqueta}". */
  etiqueta: string;
  onEdit: () => void;
  onDelete: () => void;
  deleting?: boolean;
};

/** Celda de acciones de una fila: sólo EMITE intenciones (editar, eliminar). */
export function ActionsCell({ etiqueta, onEdit, onDelete, deleting = false }: ActionsCellProps) {
  return (
    <td className="actions-cell">
      <Button variant="secondary" onClick={onEdit} aria-label={`Editar ${etiqueta}`}>
        Editar
      </Button>
      <Button
        variant="danger"
        onClick={onDelete}
        loading={deleting}
        loadingText="Eliminando..."
        aria-label={`Eliminar ${etiqueta}`}
      >
        Eliminar
      </Button>
    </td>
  );
}
