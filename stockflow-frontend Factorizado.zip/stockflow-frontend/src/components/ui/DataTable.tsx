import type { ReactNode } from 'react';

type DataTableProps = {
  headers: string[];
  /** Filas <tr> del cuerpo de la tabla. */
  children: ReactNode;
};

/** Tabla con tarjeta y scroll horizontal. Sólo conoce las cabeceras; las filas las arma cada feature. */
export function DataTable({ headers, children }: DataTableProps) {
  return (
    <div className="table-card">
      <div className="table-responsive">
        <table className="data-table">
          <thead>
            <tr>
              {headers.map((header) => (
                <th key={header}>{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>{children}</tbody>
        </table>
      </div>
    </div>
  );
}
