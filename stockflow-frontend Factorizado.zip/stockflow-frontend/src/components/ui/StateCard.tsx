/** Tarjeta de estado simple: "Cargando...". */
export function StateCard({ children }: { children: string }) {
  return <div className="state-card">{children}</div>;
}
