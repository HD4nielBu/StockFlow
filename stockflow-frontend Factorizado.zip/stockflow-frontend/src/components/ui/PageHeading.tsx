type PageHeadingProps = {
  title: string;
  description: string;
  eyebrow?: string;
  level?: 'h1' | 'h2';
};

/** Encabezado de página o de sección: etiqueta superior opcional, título y descripción. */
export function PageHeading({ title, description, eyebrow, level: Title = 'h1' }: PageHeadingProps) {
  return (
    <div className="page-heading">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <Title>{title}</Title>
      <p>{description}</p>
    </div>
  );
}
