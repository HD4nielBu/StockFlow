import type { InputHTMLAttributes, ReactNode } from 'react';

type FormFieldProps = {
  label: string;
  error?: string;
  /** Ocupa las dos columnas del form-grid. */
  wide?: boolean;
  /** El control: <input>, <select> o <textarea>. */
  children: ReactNode;
};

/** Etiqueta + control + mensaje de error junto al campo. */
export function FormField({ label, error, wide = false, children }: FormFieldProps) {
  return (
    <label className={wide ? 'form-span-2' : undefined}>
      {label}
      {children}
      {error && <small className="field-error">{error}</small>}
    </label>
  );
}

type CheckboxFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'children'> & { children: ReactNode };

export function CheckboxField({ children, ...inputProps }: CheckboxFieldProps) {
  return (
    <label className="checkbox-field form-span-2">
      <input type="checkbox" {...inputProps} />
      {children}
    </label>
  );
}
