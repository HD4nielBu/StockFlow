import type { FormEventHandler, ReactNode } from 'react';
import { Alert } from './Alert';
import { Button } from './Button';

type EntityFormProps = {
  title: string;
  /** Nombre de la entidad en minúscula ("categoría"): arma el aria-label y el texto del botón. */
  entidad: string;
  isEditing: boolean;
  saving: boolean;
  apiError: string;
  onSubmit: FormEventHandler<HTMLFormElement>;
  onCancelEdit: () => void;
  /** Campos del formulario (dentro del form-grid). */
  children: ReactNode;
};

/** G04/G06: estructura común de los formularios de crear/editar: título, campos, error de API y acciones. */
export function EntityForm({ title, entidad, isEditing, saving, apiError, onSubmit, onCancelEdit, children }: EntityFormProps) {
  return (
    <form className="entity-form" onSubmit={onSubmit} noValidate aria-label={`Formulario de ${entidad}`}>
      <h2>{title}</h2>
      <div className="form-grid">{children}</div>
      {apiError && <Alert kind="error">{apiError}</Alert>}
      <div className="form-actions">
        {isEditing && (
          <Button variant="secondary" onClick={onCancelEdit} disabled={saving}>
            Cancelar edición
          </Button>
        )}
        <Button type="submit" loading={saving} loadingText="Guardando...">
          {`${isEditing ? 'Actualizar' : 'Crear'} ${entidad}`}
        </Button>
      </div>
    </form>
  );
}
