import { Link } from 'react-router';
import { DataTable } from '../components/ui/DataTable';
import { EmptyState } from '../components/ui/EmptyState';
import { MetricCard } from '../components/ui/MetricCard';
import { PageFeedback } from '../components/ui/PageFeedback';
import { PageHeading } from '../components/ui/PageHeading';
import { StateCard } from '../components/ui/StateCard';
import { useCategorias } from '../features/categorias/hooks/useCategorias';
import { inventarioService } from '../features/inventario/services/inventarioService';
import { useProductos } from '../features/productos/hooks/useProductos';
import { useAsyncList } from '../shared/hooks/useAsyncList';
import { contarActivos } from '../shared/utils/filtros';

const CABECERAS_STOCK = ['Producto', 'Ubicación', 'Cantidad', 'Mínimo'];

/**
 * G10: el Dashboard no crea otra fuente de verdad. Las métricas son DATOS DERIVADOS de las
 * colecciones que ya entregan los hooks. Con mucho volumen, deberían venir de un endpoint
 * agregado del backend en lugar de descargar todo para contar.
 */
export default function DashboardPage() {
  const categorias = useCategorias();
  const productos = useProductos();
  const stockBajo = useAsyncList(inventarioService.stockBajoMinimo);

  if (categorias.loading || productos.loading || stockBajo.loading) {
    return <StateCard>Cargando panel...</StateCard>;
  }
  // || y no ??: un error vacío es '' (no null), así que ?? nunca pasaría al siguiente
  const error = categorias.error || productos.error || stockBajo.error;
  const alertas = stockBajo.data.length;

  return (
    <section className="page-stack">
      <PageHeading eyebrow="Panel principal" title="Resumen del inventario" description="Datos en vivo desde el backend Spring Boot." />

      <PageFeedback errors={[error]} />

      <div className="stats-grid">
        <MetricCard
          label="Categorías"
          value={categorias.data.length}
          helper={`${contarActivos(categorias.data)} activas`}
        />
        <MetricCard
          label="Productos"
          value={productos.data.length}
          helper={`${contarActivos(productos.data)} activos`}
        />
        <MetricCard
          label="Alertas de stock mínimo"
          value={alertas}
          helper="existencias en o bajo su mínimo"
          tone={alertas > 0 ? 'warning' : 'default'}
        />
      </div>

      <PageHeading
        level="h2"
        title="Stock bajo (RF-20)"
        description="Existencias por producto y ubicación que alcanzaron su stock mínimo."
      />
      {alertas === 0 ? (
        <EmptyState title="Sin alertas" description="Todas las existencias están por encima de su mínimo." />
      ) : (
        <DataTable headers={CABECERAS_STOCK}>
          {stockBajo.data.map((e) => (
            <tr key={e.stockId}>
              <td>
                <span className="code-cell">{e.codigoProducto}</span> · {e.producto}
              </td>
              <td>{e.ubicacion}</td>
              <td className="danger-cell">{e.cantidad}</td>
              <td>{e.stockMinimo}</td>
            </tr>
          ))}
        </DataTable>
      )}
      <p className="muted-cell">
        Gestiona el catálogo en <Link to="/categorias">Categorías</Link> y <Link to="/productos">Productos</Link>.
      </p>
    </section>
  );
}
