import { createCrudService } from '../../../api/createCrudService';
import type { Producto } from '../models/Producto';
import type { ProductoCreateRequest, ProductoUpdateRequest } from '../types/ProductoRequests';

/**
 * G07: CRUD de la entidad hija. Para el selector de categorías se reutiliza categoriaService.
 * actualizar → 422 si se mueve el producto a una categoría inactiva; eliminar → 409 si tiene stock o movimientos (RN-01).
 */
export const productoService = createCrudService<Producto, ProductoCreateRequest, ProductoUpdateRequest>('/productos');
