import { useMemo } from 'react';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog';
import { EmptyState } from '../../../components/ui/EmptyState';
import { PageFeedback } from '../../../components/ui/PageFeedback';
import { PageHeading } from '../../../components/ui/PageHeading';
import { Pagination } from '../../../components/ui/Pagination';
import { SearchInput } from '../../../components/ui/SearchInput';
import { SelectFilter } from '../../../components/ui/SelectFilter';
import { StateCard } from '../../../components/ui/StateCard';
import { useCrudPage } from '../../../shared/hooks/useCrudPage';
import { useListFilters } from '../../../shared/hooks/useListFilters';
import { coincideEstado, coincideTexto, OPCIONES_TAMANO, opcionesEstado } from '../../../shared/utils/filtros';
import { paginar } from '../../../shared/utils/paginar';
import { useCategorias } from '../../categorias/hooks/useCategorias';
import type { Categoria } from '../../categorias/models/Categoria';
import ProductoForm from '../components/ProductoForm';
import ProductoTable from '../components/ProductoTable';
import { useProductos } from '../hooks/useProductos';
import type { Producto } from '../models/Producto';
import { productoService } from '../services/productoService';

const ESTADOS = opcionesEstado('Todos', 'Activos', 'Inactivos');

const MENSAJES = {
  errorCargar: 'No se pudo cargar el producto',
  errorEliminar: 'No se pudo eliminar el producto',
  creado: (p: Producto) => `Producto ${p.codigo} creado`,
  actualizado: (p: Producto) => `Producto ${p.codigo} actualizado`,
  eliminado: (p: Producto) => `Producto ${p.codigo} eliminado`,
};

/** G07/G08/G09: CRUD de Producto + relación Categoría 1:N + búsqueda, filtros y paginación. */
export default function ProductosPage() {
  const productos = useProductos();
  const categorias = useCategorias();
  const crud = useCrudPage<Producto>({ service: productoService, setData: productos.setData, mensajes: MENSAJES });
  const { filters, setFilter, page, setPage, pageSize, setPageSize } = useListFilters({
    search: '',
    categoria: 'all',
    status: 'all',
  });

  // G07: Map id -> Categoria para resolver nombres sin una petición por fila
  const categoriasPorId = useMemo(
    () => new Map<number, Categoria>(categorias.data.map((c) => [c.id, c])),
    [categorias.data],
  );

  const filtrados = productos.data.filter((p) => {
    const categoria = categoriasPorId.get(p.categoriaId);
    return (
      coincideTexto(filters.search, [p.codigo, p.nombre, categoria?.nombre, categoria?.codigo]) &&
      // El select entrega string: se convierte a number para comparar con categoriaId
      (filters.categoria === 'all' || p.categoriaId === Number(filters.categoria)) &&
      coincideEstado(p.activo, filters.status)
    );
  });
  const pagina = paginar(filtrados, page, pageSize);

  if (productos.loading || categorias.loading) return <StateCard>Cargando productos...</StateCard>;

  const opcionesCategoria = [{ value: 'all', label: 'Todas' }, ...categorias.data.map((c) => ({ value: String(c.id), label: c.nombre }))];

  return (
    <section className="page-stack">
      <PageHeading
        eyebrow="Entidad hija · Categoría 1:N Producto · RF-05"
        title="Productos"
        description="CRUD completo conectado con Spring Boot (/api/productos)."
      />

      <PageFeedback
        errors={[productos.error || categorias.error, crud.error]}
        success={crud.success}
        loadingDetail={crud.loadingDetail}
      />

      <ProductoForm
        key={crud.editing?.id ?? 'nuevo'}
        categorias={categorias.data}
        producto={crud.editing}
        onSaved={crud.handleSaved}
        onCancelEdit={crud.cancelEdit}
      />

      <div className="toolbar">
        <SearchInput
          value={filters.search}
          label="Buscar producto"
          placeholder="Código, nombre o categoría"
          onChange={(v) => setFilter('search', v)}
        />
        <SelectFilter
          label="Categoría"
          value={filters.categoria}
          options={opcionesCategoria}
          onChange={(v) => setFilter('categoria', v)}
        />
        <SelectFilter label="Estado" value={filters.status} options={ESTADOS} onChange={(v) => setFilter('status', v)} />
        <SelectFilter
          label="Tamaño"
          value={String(pageSize)}
          options={OPCIONES_TAMANO}
          onChange={(v) => setPageSize(Number(v))}
        />
      </div>

      {pagina.totalItems === 0 ? (
        <EmptyState
          title={productos.data.length === 0 ? 'No hay productos registrados' : 'Ningún producto coincide con los filtros'}
          description={productos.data.length === 0 ? 'Crea el primero con el formulario.' : 'Cambia la búsqueda o los filtros.'}
        />
      ) : (
        <>
          <ProductoTable
            productos={pagina.items}
            categoriasPorId={categoriasPorId}
            onEdit={crud.handleEdit}
            onDelete={crud.askDelete}
            deletingId={crud.deletingId}
          />
          <Pagination page={pagina.pagina} totalPages={pagina.totalPaginas} onPageChange={setPage} />
        </>
      )}

      <ConfirmDialog
        open={crud.pendingDelete !== null}
        title="Eliminar producto"
        message={
          crud.pendingDelete
            ? `¿Eliminar el producto ${crud.pendingDelete.codigo}? Si ya tiene stock o movimientos, el backend lo impedirá.`
            : ''
        }
        confirming={crud.deletingId !== null}
        onConfirm={crud.confirmDelete}
        onCancel={crud.cancelDelete}
      />
    </section>
  );
}
