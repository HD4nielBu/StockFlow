import { EntityForm } from '../../../components/ui/EntityForm';
import { CheckboxField, FormField } from '../../../components/ui/FormField';
import { useEntityForm } from '../../../shared/hooks/useEntityForm';
import type { Categoria } from '../../categorias/models/Categoria';
import { UNIDADES_MEDIDA, type Producto } from '../models/Producto';
import { productoService } from '../services/productoService';
import type { ProductoFormData } from '../types/ProductoFormData';
import { aFormulario, aPayload, FORMULARIO_VACIO } from '../utils/productoMapper';
import { validarProducto } from '../utils/productoValidation';

interface ProductoFormProps {
  categorias: Categoria[];
  producto: Producto | null;
  onSaved: (producto: Producto, mode: 'create' | 'edit') => void;
  onCancelEdit: () => void;
}

/**
 * G07: formulario de la entidad hija. El usuario ELIGE una categoría por su nombre, pero el payload
 * envía categoriaId: la relación 1:N la valida y persiste el backend (FK producto.categoria_id).
 * Igual que CategoriaForm: la Page le pasa key={producto?.id} para reiniciarlo al cambiar de producto.
 */
export default function ProductoForm({ categorias, producto, onSaved, onCancelEdit }: ProductoFormProps) {
  const isEditing = producto !== null;
  const { errors, saving, apiError, handleSubmit, campo, casilla } = useEntityForm<ProductoFormData, Producto>({
    inicial: aFormulario(producto),
    vacio: FORMULARIO_VACIO,
    editando: isEditing,
    validar: (data) => validarProducto(data, categorias, producto?.categoriaId),
    guardar: (data) =>
      producto
        ? productoService.actualizar(producto.id, { ...aPayload(data), activo: data.activo })
        : productoService.crear(aPayload(data)),
    onSaved,
    errorPorDefecto: 'No se pudo guardar el producto',
  });

  // Opciones del select: categorías activas + la actual del producto (aunque esté inactiva, para no perderla)
  const opciones = categorias.filter((c) => c.activo || c.id === producto?.categoriaId);

  return (
    <EntityForm
      title={isEditing ? `Editar producto ${producto.codigo}` : 'Nuevo producto'}
      entidad="producto"
      isEditing={isEditing}
      saving={saving}
      apiError={apiError}
      onSubmit={handleSubmit}
      onCancelEdit={onCancelEdit}
    >
      <FormField label="Categoría" error={errors.categoriaId}>
        <select {...campo('categoriaId')}>
          <option value="">Seleccione una categoría</option>
          {opciones.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.codigo} · {c.nombre}
              {c.activo ? '' : ' (inactiva)'}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Código" error={errors.codigo}>
        <input {...campo('codigo')} placeholder="PRD-OFI-010" />
      </FormField>
      <FormField label="Nombre" error={errors.nombre} wide>
        <input {...campo('nombre')} />
      </FormField>
      <FormField label="Unidad de medida">
        <select {...campo('unidadMedida')}>
          {UNIDADES_MEDIDA.map((u) => (
            <option key={u} value={u}>
              {u}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Stock mínimo" error={errors.stockMinimoDefault}>
        <input {...campo('stockMinimoDefault')} inputMode="numeric" />
      </FormField>
      <FormField label="Precio referencial (opcional)" error={errors.precioReferencial}>
        <input {...campo('precioReferencial')} inputMode="decimal" placeholder="18.90" />
      </FormField>
      <FormField label="Descripción" error={errors.descripcion} wide>
        <textarea {...campo('descripcion')} rows={2} />
      </FormField>
      {isEditing && <CheckboxField {...casilla('activo')}>Producto activo</CheckboxField>}
    </EntityForm>
  );
}
