import { ActionsCell } from '../../../components/ui/ActionsCell';
import { DataTable } from '../../../components/ui/DataTable';
import { StatusBadge } from '../../../components/ui/StatusBadge';
import type { Categoria } from '../../categorias/models/Categoria';
import type { Producto } from '../models/Producto';

const CABECERAS = ['Código', 'Nombre', 'Categoría', 'Unidad', 'Stock mín.', 'Precio ref.', 'Estado', 'Acciones'];

const formatoPrecio = new Intl.NumberFormat('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

interface ProductoTableProps {
  productos: Producto[];
  /** G07: mapa id -> Categoria construido UNA vez por la Page. Sin un GET por fila (sin N+1 desde la UI). */
  categoriasPorId: Map<number, Categoria>;
  onEdit: (id: number) => void;
  onDelete: (producto: Producto) => void;
  deletingId?: number | null;
}

export default function ProductoTable({ productos, categoriasPorId, onEdit, onDelete, deletingId }: ProductoTableProps) {
  return (
    <DataTable headers={CABECERAS}>
      {productos.map((producto) => {
        const categoria = categoriasPorId.get(producto.categoriaId);
        return (
          <tr key={producto.id}>
            <td className="code-cell">{producto.codigo}</td>
            <td>{producto.nombre}</td>
            <td>{categoria ? `${categoria.codigo} · ${categoria.nombre}` : `Categoría #${producto.categoriaId}`}</td>
            <td>{producto.unidadMedida}</td>
            <td>{producto.stockMinimoDefault}</td>
            <td>{producto.precioReferencial === null ? '—' : formatoPrecio.format(producto.precioReferencial)}</td>
            <td>
              <StatusBadge active={producto.activo} />
            </td>
            <ActionsCell
              etiqueta={producto.codigo}
              onEdit={() => onEdit(producto.id)}
              onDelete={() => onDelete(producto)}
              deleting={deletingId === producto.id}
            />
          </tr>
        );
      })}
    </DataTable>
  );
}
