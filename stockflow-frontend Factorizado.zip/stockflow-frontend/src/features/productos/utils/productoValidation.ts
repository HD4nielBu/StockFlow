import { sinVacios, validarCodigo, validarDescripcion, validarNombre } from '../../../shared/utils/validacion';
import type { Categoria } from '../../categorias/models/Categoria';
import type { ProductoFormData } from '../types/ProductoFormData';

export type ProductoFormErrors = Partial<Record<keyof ProductoFormData, string>>;

const PRECIO = /^\d{1,10}(\.\d{1,2})?$/; // NUMERIC(12,2): hasta 10 enteros y 2 decimales

/**
 * Regla de relación: un producto NUEVO o que CAMBIA de categoría sólo puede ir a una categoría activa
 * (la misma regla que aplica ProductoService en el backend; si no, respondería 422).
 * categoriaActualId es la categoría que el producto ya tenía (sólo al editar).
 */
function validarCategoriaDestino(categoriaId: string, categorias: Categoria[], categoriaActualId?: number) {
  if (!categoriaId) return 'Seleccione una categoría';
  const categoria = categorias.find((c) => c.id === Number(categoriaId));
  if (!categoria) return 'La categoría seleccionada no existe';
  if (!categoria.activo && categoria.id !== categoriaActualId) {
    return 'La categoría está inactiva y no admite productos nuevos';
  }
  return undefined;
}

function validarStockMinimo(valor: string) {
  const minimo = valor.trim();
  if (minimo === '') return 'El stock mínimo es obligatorio';
  if (!/^\d+$/.test(minimo)) return 'RN-07: debe ser un entero mayor o igual a 0';
  return undefined;
}

function validarPrecio(valor: string) {
  const precio = valor.trim();
  return precio !== '' && !PRECIO.test(precio) ? 'Precio no negativo, con hasta 2 decimales' : undefined;
}

/** G04/G07: reglas de CrearProductoRequest más la regla de relación con la categoría. */
export function validarProducto(
  data: ProductoFormData,
  categorias: Categoria[],
  categoriaActualId?: number,
): ProductoFormErrors {
  return sinVacios<keyof ProductoFormData>({
    categoriaId: validarCategoriaDestino(data.categoriaId, categorias, categoriaActualId),
    codigo: validarCodigo(data.codigo, 40),
    nombre: validarNombre(data.nombre, 140),
    descripcion: validarDescripcion(data.descripcion),
    stockMinimoDefault: validarStockMinimo(data.stockMinimoDefault),
    precioReferencial: validarPrecio(data.precioReferencial),
  });
}
