import type { Producto } from '../models/Producto';
import type { ProductoFormData } from '../types/ProductoFormData';
import type { ProductoCreateRequest } from '../types/ProductoRequests';

export const FORMULARIO_VACIO: ProductoFormData = {
  categoriaId: '',
  codigo: '',
  nombre: '',
  descripcion: '',
  unidadMedida: 'UNIDAD',
  stockMinimoDefault: '0',
  precioReferencial: '',
  activo: true,
};

/** G07: copia el producto a editar al estado editable; los números pasan a texto para los <input>. */
export function aFormulario(producto: Producto | null): ProductoFormData {
  return producto
    ? {
        categoriaId: String(producto.categoriaId),
        codigo: producto.codigo,
        nombre: producto.nombre,
        descripcion: producto.descripcion ?? '',
        unidadMedida: producto.unidadMedida,
        stockMinimoDefault: String(producto.stockMinimoDefault),
        precioReferencial: producto.precioReferencial === null ? '' : producto.precioReferencial.toFixed(2),
        activo: producto.activo,
      }
    : FORMULARIO_VACIO;
}

/** Convierte el texto del formulario en el payload tipado. Sólo se llama DESPUÉS de validar. */
export function aPayload(data: ProductoFormData): ProductoCreateRequest {
  return {
    categoriaId: Number(data.categoriaId),
    codigo: data.codigo.trim(),
    nombre: data.nombre.trim(),
    descripcion: data.descripcion.trim() || null,
    unidadMedida: data.unidadMedida,
    stockMinimoDefault: Number(data.stockMinimoDefault),
    precioReferencial: data.precioReferencial.trim() === '' ? null : Number(data.precioReferencial),
  };
}
