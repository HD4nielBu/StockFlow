import { sinVacios, validarCodigo, validarDescripcion, validarNombre } from '../../../shared/utils/validacion';
import type { CategoriaFormData } from '../types/CategoriaFormData';

export type CategoriaFormErrors = Partial<Record<keyof CategoriaFormData, string>>;

/**
 * G04: mismas reglas que CrearCategoriaRequest del backend (@NotBlank, @Size, @Pattern).
 * Mejoran la experiencia (error inmediato junto al campo), pero NO reemplazan la validación
 * de Spring Boot ni las constraints de PostgreSQL.
 */
export function validarCategoria(data: CategoriaFormData): CategoriaFormErrors {
  return sinVacios<keyof CategoriaFormData>({
    codigo: validarCodigo(data.codigo, 30),
    nombre: validarNombre(data.nombre, 100),
    descripcion: validarDescripcion(data.descripcion),
  });
}
