import type { Categoria } from '../models/Categoria';
import type { CategoriaFormData } from '../types/CategoriaFormData';
import type { CategoriaCreateRequest } from '../types/CategoriaRequests';

export const FORMULARIO_VACIO: CategoriaFormData = { codigo: '', nombre: '', descripcion: '', activo: true };

/** G06: copia la categoría a editar al estado editable (o el formulario vacío en modo crear). */
export function aFormulario(categoria: Categoria | null): CategoriaFormData {
  return categoria
    ? { codigo: categoria.codigo, nombre: categoria.nombre, descripcion: categoria.descripcion ?? '', activo: categoria.activo }
    : FORMULARIO_VACIO;
}

/** Convierte el texto del formulario en el payload tipado. Sólo se llama DESPUÉS de validar. */
export function aPayload(data: CategoriaFormData): CategoriaCreateRequest {
  return {
    codigo: data.codigo.trim(),
    nombre: data.nombre.trim(),
    descripcion: data.descripcion.trim() || null,
  };
}
