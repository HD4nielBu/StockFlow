import { useMemo } from 'react';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog';
import { EmptyState } from '../../../components/ui/EmptyState';
import { PageFeedback } from '../../../components/ui/PageFeedback';
import { PageHeading } from '../../../components/ui/PageHeading';
import { Pagination } from '../../../components/ui/Pagination';
import { SearchInput } from '../../../components/ui/SearchInput';
import { SelectFilter } from '../../../components/ui/SelectFilter';
import { StateCard } from '../../../components/ui/StateCard';
import { useCrudPage } from '../../../shared/hooks/useCrudPage';
import { useListFilters } from '../../../shared/hooks/useListFilters';
import { coincideEstado, coincideTexto, OPCIONES_TAMANO, opcionesEstado } from '../../../shared/utils/filtros';
import { paginar } from '../../../shared/utils/paginar';
import { useProductos } from '../../productos/hooks/useProductos';
import CategoriaForm from '../components/CategoriaForm';
import CategoriaTable from '../components/CategoriaTable';
import { useCategorias } from '../hooks/useCategorias';
import type { Categoria } from '../models/Categoria';
import { categoriaService } from '../services/categoriaService';

const ESTADOS = opcionesEstado('Todas', 'Activas', 'Inactivas');

const MENSAJES = {
  errorCargar: 'No se pudo cargar la categoría',
  errorEliminar: 'No se pudo eliminar la categoría',
  creado: (c: Categoria) => `Categoría ${c.codigo} creada`,
  actualizado: (c: Categoria) => `Categoría ${c.codigo} actualizada`,
  eliminado: (c: Categoria) => `Categoría ${c.codigo} eliminada`,
};

/**
 * G06/G08/G09: la Page coordina el caso de uso: carga (hook), edición, eliminación,
 * búsqueda, filtros y paginación. Los componentes UI sólo reciben datos y callbacks.
 */
export default function CategoriasPage() {
  const { data: categorias, setData, loading, error: errorCarga } = useCategorias();
  const { data: productos } = useProductos();
  const crud = useCrudPage<Categoria>({ service: categoriaService, setData, mensajes: MENSAJES });
  const { filters, setFilter, page, setPage, pageSize, setPageSize } = useListFilters({ search: '', status: 'all' });

  // Datos DERIVADOS: se calculan en cada render, no se guardan en otro useState (G08/G09)
  const productosPorCategoria = useMemo(() => {
    const conteo = new Map<number, number>();
    productos.forEach((p) => conteo.set(p.categoriaId, (conteo.get(p.categoriaId) ?? 0) + 1));
    return conteo;
  }, [productos]);

  // AND entre filtros, OR entre campos de texto
  const filtradas = categorias.filter(
    (c) => coincideTexto(filters.search, [c.codigo, c.nombre, c.descripcion]) && coincideEstado(c.activo, filters.status),
  );
  const pagina = paginar(filtradas, page, pageSize); // primero filtrar, después paginar

  if (loading) return <StateCard>Cargando categorías...</StateCard>;

  return (
    <section className="page-stack">
      <PageHeading
        eyebrow="Entidad padre · RF-06"
        title="Categorías"
        description="CRUD completo conectado con Spring Boot (/api/categorias)."
      />

      <PageFeedback errors={[errorCarga, crud.error]} success={crud.success} loadingDetail={crud.loadingDetail} />

      <CategoriaForm
        key={crud.editing?.id ?? 'nueva'}
        categoria={crud.editing}
        onSaved={crud.handleSaved}
        onCancelEdit={crud.cancelEdit}
      />

      <div className="toolbar">
        <SearchInput
          value={filters.search}
          label="Buscar categoría"
          placeholder="Código, nombre o descripción"
          onChange={(v) => setFilter('search', v)}
        />
        <SelectFilter label="Estado" value={filters.status} options={ESTADOS} onChange={(v) => setFilter('status', v)} />
        <SelectFilter
          label="Tamaño"
          value={String(pageSize)}
          options={OPCIONES_TAMANO}
          onChange={(v) => setPageSize(Number(v))}
        />
      </div>

      {pagina.totalItems === 0 ? (
        <EmptyState
          title={categorias.length === 0 ? 'No hay categorías registradas' : 'Ninguna categoría coincide con la búsqueda'}
          description={categorias.length === 0 ? 'Crea la primera con el formulario.' : 'Cambia el texto o el filtro de estado.'}
        />
      ) : (
        <>
          <CategoriaTable
            categorias={pagina.items}
            productosPorCategoria={productosPorCategoria}
            onEdit={crud.handleEdit}
            onDelete={crud.askDelete}
            deletingId={crud.deletingId}
          />
          <Pagination page={pagina.pagina} totalPages={pagina.totalPaginas} onPageChange={setPage} />
        </>
      )}

      <ConfirmDialog
        open={crud.pendingDelete !== null}
        title="Eliminar categoría"
        message={
          crud.pendingDelete
            ? `¿Eliminar la categoría ${crud.pendingDelete.codigo} (${crud.pendingDelete.nombre})? Si tiene productos, el backend lo impedirá.`
            : ''
        }
        confirming={crud.deletingId !== null}
        onConfirm={crud.confirmDelete}
        onCancel={crud.cancelDelete}
      />
    </section>
  );
}
