import { CheckboxField, FormField } from '../../../components/ui/FormField';
import { EntityForm } from '../../../components/ui/EntityForm';
import { useEntityForm } from '../../../shared/hooks/useEntityForm';
import type { Categoria } from '../models/Categoria';
import { categoriaService } from '../services/categoriaService';
import type { CategoriaFormData } from '../types/CategoriaFormData';
import { aFormulario, aPayload, FORMULARIO_VACIO } from '../utils/categoriaMapper';
import { validarCategoria } from '../utils/categoriaValidation';

interface CategoriaFormProps {
  /** null = modo crear; una categoría = modo editar. */
  categoria: Categoria | null;
  onSaved: (categoria: Categoria, mode: 'create' | 'edit') => void;
  onCancelEdit: () => void;
}

/**
 * G04/G06: un solo formulario para crear (POST) y editar (PUT).
 * La decisión POST/PUT depende de si existe una categoría persistida (con id), no del texto del botón.
 * La Page lo renderiza con key={categoria?.id} para reiniciarlo al cambiar la categoría a editar.
 */
export default function CategoriaForm({ categoria, onSaved, onCancelEdit }: CategoriaFormProps) {
  const isEditing = categoria !== null;
  const { errors, saving, apiError, handleSubmit, campo, casilla } = useEntityForm<CategoriaFormData, Categoria>({
    inicial: aFormulario(categoria),
    vacio: FORMULARIO_VACIO,
    editando: isEditing,
    validar: validarCategoria,
    guardar: (data) =>
      categoria
        ? categoriaService.actualizar(categoria.id, { ...aPayload(data), activo: data.activo })
        : categoriaService.crear(aPayload(data)),
    onSaved,
    errorPorDefecto: 'No se pudo guardar la categoría',
  });

  return (
    <EntityForm
      title={isEditing ? `Editar categoría #${categoria.id}` : 'Nueva categoría'}
      entidad="categoría"
      isEditing={isEditing}
      saving={saving}
      apiError={apiError}
      onSubmit={handleSubmit}
      onCancelEdit={onCancelEdit}
    >
      <FormField label="Código" error={errors.codigo}>
        <input {...campo('codigo')} placeholder="CAT-OFI" />
      </FormField>
      <FormField label="Nombre" error={errors.nombre}>
        <input {...campo('nombre')} placeholder="Material de oficina" />
      </FormField>
      <FormField label="Descripción" error={errors.descripcion} wide>
        <textarea {...campo('descripcion')} rows={2} />
      </FormField>
      {isEditing && (
        <CheckboxField {...casilla('activo')}>Categoría activa (una inactiva no admite productos nuevos)</CheckboxField>
      )}
    </EntityForm>
  );
}
