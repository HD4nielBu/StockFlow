import { ActionsCell } from '../../../components/ui/ActionsCell';
import { DataTable } from '../../../components/ui/DataTable';
import { StatusBadge } from '../../../components/ui/StatusBadge';
import type { Categoria } from '../models/Categoria';

const CABECERAS = ['ID', 'Código', 'Nombre', 'Descripción', 'Productos', 'Estado', 'Acciones'];

interface CategoriaTableProps {
  categorias: Categoria[];
  /** Cantidad de productos por categoría (dato derivado que calcula la Page). */
  productosPorCategoria?: Map<number, number>;
  onEdit: (id: number) => void;
  onDelete: (categoria: Categoria) => void;
  deletingId?: number | null;
}

/**
 * G03/G06: muestra filas y EMITE intenciones (onEdit, onDelete) hacia la Page.
 * No importa categoriaService: la tabla no decide cómo se habla con el backend.
 */
export default function CategoriaTable({ categorias, productosPorCategoria, onEdit, onDelete, deletingId }: CategoriaTableProps) {
  return (
    <DataTable headers={CABECERAS}>
      {categorias.map((categoria) => (
        <tr key={categoria.id}>
          <td>{categoria.id}</td>
          <td className="code-cell">{categoria.codigo}</td>
          <td>{categoria.nombre}</td>
          <td className="muted-cell">{categoria.descripcion ?? '—'}</td>
          <td>{productosPorCategoria?.get(categoria.id) ?? 0}</td>
          <td>
            <StatusBadge active={categoria.activo} />
          </td>
          <ActionsCell
            etiqueta={categoria.nombre}
            onEdit={() => onEdit(categoria.id)}
            onDelete={() => onDelete(categoria)}
            deleting={deletingId === categoria.id}
          />
        </tr>
      ))}
    </DataTable>
  );
}
