import { createCrudService } from '../../../api/createCrudService';
import type { Categoria } from '../models/Categoria';
import type { CategoriaCreateRequest, CategoriaUpdateRequest } from '../types/CategoriaRequests';

/** G06: el único lugar que conoce la ruta de categorías. eliminar → 409 si la categoría tiene productos. */
export const categoriaService = createCrudService<Categoria, CategoriaCreateRequest, CategoriaUpdateRequest>('/categorias');
