import type { Option } from '../../components/ui/SelectFilter';
import { normalizar } from './paginar';

/** G09: opciones del selector de estado. Sólo cambia el género de las etiquetas ("Todas" / "Todos"). */
export const opcionesEstado = (todos: string, activos: string, inactivos: string): Option[] => [
  { value: 'all', label: todos },
  { value: 'active', label: activos },
  { value: 'inactive', label: inactivos },
];

export const OPCIONES_TAMANO: Option[] = [5, 10, 20].map((n) => ({ value: String(n), label: `${n} por página` }));

/** Búsqueda sin tildes ni mayúsculas: coincide si el término aparece en CUALQUIER campo (OR entre campos). */
export function coincideTexto(busqueda: string, campos: Array<string | null | undefined>): boolean {
  const termino = normalizar(busqueda);
  return !termino || campos.some((campo) => normalizar(campo).includes(termino));
}

export function coincideEstado(activo: boolean, estado: string): boolean {
  return estado === 'all' || (estado === 'active' ? activo : !activo);
}

export function contarActivos(items: Array<{ activo: boolean }>): number {
  return items.filter((item) => item.activo).length;
}
