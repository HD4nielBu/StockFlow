import { describe, expect, it } from 'vitest';
import { sinVacios, validarCodigo, validarDescripcion, validarNombre } from './validacion';

describe('validacion compartida', () => {
  it('validarCodigo aplica obligatorio, máximo y patrón', () => {
    expect(validarCodigo('  ', 30)).toBe('El código es obligatorio');
    expect(validarCodigo('C'.repeat(41), 40)).toBe('El código admite máximo 40 caracteres');
    expect(validarCodigo('CAT OFI', 30)).toBe('Sólo letras, números y guiones');
    expect(validarCodigo('CAT-OFI', 30)).toBeUndefined();
  });

  it('validarNombre y validarDescripcion respetan sus máximos', () => {
    expect(validarNombre('', 100)).toBe('El nombre es obligatorio');
    expect(validarNombre('N'.repeat(141), 140)).toBe('El nombre admite máximo 140 caracteres');
    expect(validarDescripcion('d'.repeat(1001))).toBe('La descripción admite máximo 1000 caracteres');
    expect(validarDescripcion('')).toBeUndefined();
  });

  it('sinVacios elimina los campos sin error', () => {
    expect(sinVacios({ codigo: undefined, nombre: 'Falta' })).toStrictEqual({ nombre: 'Falta' });
  });
});
