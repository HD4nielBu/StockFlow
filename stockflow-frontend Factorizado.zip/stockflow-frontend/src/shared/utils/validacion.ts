/** G04: reglas de validación que comparten Categoría y Producto (mismas del backend: @NotBlank, @Size, @Pattern). */
const CODIGO = /^[A-Za-z0-9-]+$/;
const DESCRIPCION_MAX = 1000;

export function validarCodigo(valor: string, max: number): string | undefined {
  const codigo = valor.trim();
  if (!codigo) return 'El código es obligatorio';
  if (codigo.length > max) return `El código admite máximo ${max} caracteres`;
  if (!CODIGO.test(codigo)) return 'Sólo letras, números y guiones';
  return undefined;
}

export function validarNombre(valor: string, max: number): string | undefined {
  const nombre = valor.trim();
  if (!nombre) return 'El nombre es obligatorio';
  if (nombre.length > max) return `El nombre admite máximo ${max} caracteres`;
  return undefined;
}

export function validarDescripcion(valor: string): string | undefined {
  return valor.length > DESCRIPCION_MAX ? `La descripción admite máximo ${DESCRIPCION_MAX} caracteres` : undefined;
}

/** Quita los campos sin error: así Object.keys(errores).length === 0 significa "formulario válido". */
export function sinVacios<K extends string>(errores: Partial<Record<K, string | undefined>>): Partial<Record<K, string>> {
  return Object.fromEntries(Object.entries(errores).filter(([, mensaje]) => mensaje)) as Partial<Record<K, string>>;
}
