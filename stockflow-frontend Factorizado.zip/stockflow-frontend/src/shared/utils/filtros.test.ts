import { describe, expect, it } from 'vitest';
import { coincideEstado, coincideTexto, contarActivos } from './filtros';

describe('coincideTexto', () => {
  it('una búsqueda vacía coincide con todo', () => {
    expect(coincideTexto('  ', ['Limpieza'])).toBe(true);
  });

  it('ignora tildes y mayúsculas, y basta que coincida un campo', () => {
    expect(coincideTexto('categoria', [null, 'CAT-OLD', 'Categoría retirada'])).toBe(true);
    expect(coincideTexto('zzz', ['CAT-OLD', undefined])).toBe(false);
  });
});

describe('coincideEstado', () => {
  it('"all" deja pasar todo; "active" e "inactive" filtran por activo', () => {
    expect(coincideEstado(false, 'all')).toBe(true);
    expect(coincideEstado(true, 'active')).toBe(true);
    expect(coincideEstado(false, 'active')).toBe(false);
    expect(coincideEstado(false, 'inactive')).toBe(true);
  });
});

describe('contarActivos', () => {
  it('cuenta sólo los elementos activos', () => {
    expect(contarActivos([{ activo: true }, { activo: false }, { activo: true }])).toBe(2);
  });
});
