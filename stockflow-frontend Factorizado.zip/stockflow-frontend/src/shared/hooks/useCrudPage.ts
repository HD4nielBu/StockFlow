import { useEffect, useRef, useState, type Dispatch, type SetStateAction } from 'react';
import { mensajeDeError } from '../../api/apiClient';

interface CrudService<T> {
  obtenerPorId: (id: number) => Promise<T>;
  eliminar: (id: number) => Promise<void>;
}

interface CrudMensajes<T> {
  errorCargar: string;
  errorEliminar: string;
  creado: (item: T) => string;
  actualizado: (item: T) => string;
  eliminado: (item: T) => string;
}

interface UseCrudPageOptions<T> {
  service: CrudService<T>;
  /** setData de useAsyncList: la lista local se sincroniza con la RESPUESTA del backend. */
  setData: Dispatch<SetStateAction<T[]>>;
  mensajes: CrudMensajes<T>;
}

/**
 * G06/G08: caso de uso común de las pages CRUD: editar (GET /{id}), guardar, eliminar con confirmación,
 * y los mensajes de error y éxito. La Page sólo agrega lo propio de su entidad (filtros, tabla, formulario).
 */
export function useCrudPage<T extends { id: number }>({ service, setData, mensajes }: UseCrudPageOptions<T>) {
  const [editing, setEditing] = useState<T | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<T | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const successTimer = useRef<number | undefined>(undefined);

  // Al desmontar se cancela el temporizador del mensaje de éxito
  useEffect(() => () => window.clearTimeout(successTimer.current), []);

  const mostrarExito = (mensaje: string) => {
    window.clearTimeout(successTimer.current);
    setSuccess(mensaje);
    successTimer.current = window.setTimeout(() => setSuccess(''), 3000);
  };

  // GET /{id} antes de editar, para trabajar con la versión actual del servidor
  const handleEdit = async (id: number) => {
    try {
      setLoadingDetail(true);
      setError('');
      setEditing(await service.obtenerPorId(id));
    } catch (err) {
      setError(mensajeDeError(err, mensajes.errorCargar));
    } finally {
      setLoadingDetail(false);
    }
  };

  // La respuesta del backend trae el id real y los datos normalizados
  const handleSaved = (saved: T, mode: 'create' | 'edit') => {
    setData((prev) => (mode === 'create' ? [...prev, saved] : prev.map((item) => (item.id === saved.id ? saved : item))));
    setEditing(null);
    mostrarExito((mode === 'create' ? mensajes.creado : mensajes.actualizado)(saved));
  };

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    const item = pendingDelete;
    try {
      setDeletingId(item.id);
      setError('');
      await service.eliminar(item.id);
      // Sólo se quita la fila DESPUÉS de que el backend confirmó (204)
      setData((prev) => prev.filter((otro) => otro.id !== item.id));
      setEditing((actual) => (actual?.id === item.id ? null : actual));
      mostrarExito(mensajes.eliminado(item));
    } catch (err) {
      // 409: tiene dependencias. La fila NO se borra de la pantalla: el backend la rechazó.
      setError(mensajeDeError(err, mensajes.errorEliminar));
    } finally {
      setDeletingId(null);
      setPendingDelete(null);
    }
  };

  return {
    editing,
    cancelEdit: () => setEditing(null),
    loadingDetail,
    pendingDelete,
    askDelete: setPendingDelete,
    cancelDelete: () => setPendingDelete(null),
    deletingId,
    error,
    success,
    handleEdit,
    handleSaved,
    confirmDelete,
  };
}
