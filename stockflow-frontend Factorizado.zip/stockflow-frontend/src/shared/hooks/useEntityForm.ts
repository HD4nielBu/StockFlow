import { useState, type ChangeEvent, type FormEvent } from 'react';
import { ApiError, mensajeDeError } from '../../api/apiClient';

type FormErrors<F> = Partial<Record<keyof F, string>>;

interface UseEntityFormOptions<F, T> {
  /** Valores al montar: la entidad a editar o el formulario vacío. */
  inicial: F;
  /** Valores a restaurar después de crear. */
  vacio: F;
  /** true = PUT sobre una entidad persistida; false = POST. */
  editando: boolean;
  validar: (data: F) => FormErrors<F>;
  /** Llama al service que corresponda (crear o actualizar) con los datos ya validados. */
  guardar: (data: F) => Promise<T>;
  onSaved: (entidad: T, modo: 'create' | 'edit') => void;
  errorPorDefecto: string;
}

/**
 * G04/G06/G07: formulario controlado para crear (POST) y editar (PUT).
 * La Page lo monta con key={entidad?.id}: al cambiar la entidad, React lo vuelve a montar y useState toma
 * el nuevo valor inicial (en vez de copiar props al estado con un Effect).
 */
export function useEntityForm<F extends object, T>({
  inicial,
  vacio,
  editando,
  validar,
  guardar,
  onSaved,
  errorPorDefecto,
}: UseEntityFormOptions<F, T>) {
  const [formData, setFormData] = useState<F>(inicial);
  const [errors, setErrors] = useState<FormErrors<F>>({});
  const [saving, setSaving] = useState(false);
  const [apiError, setApiError] = useState('');

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const valor = e.target instanceof HTMLInputElement && e.target.type === 'checkbox' ? e.target.checked : value;
    // Inmutabilidad: se crea un objeto nuevo con ...prev; nunca formData.nombre = ...
    setFormData((prev) => ({ ...prev, [name]: valor }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); // la SPA no recarga la página
    setApiError('');
    const validationErrors = validar(formData);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return; // no se envía una petición que fallaría

    try {
      setSaving(true);
      onSaved(await guardar(formData), editando ? 'edit' : 'create');
      if (!editando) setFormData(vacio);
    } catch (err) {
      // 400 del backend: se muestran sus errores junto a cada campo; 409: código o nombre repetido
      if (err instanceof ApiError) setErrors(err.fieldErrors as FormErrors<F>);
      setApiError(mensajeDeError(err, errorPorDefecto));
    } finally {
      setSaving(false);
    }
  };

  /** Props de un <input>/<select>/<textarea> de texto enlazado al estado: {...campo('codigo')}. */
  const campo = (name: keyof F & string) => ({ name, value: String(formData[name]), onChange: handleChange });

  /** Props de un checkbox enlazado al estado: {...casilla('activo')}. */
  const casilla = (name: keyof F & string) => ({ name, checked: Boolean(formData[name]), onChange: handleChange });

  return { errors, saving, apiError, handleSubmit, campo, casilla };
}
