import { useState } from 'react';

/**
 * G09: estado fuente de búsqueda, filtros y paginación del cliente.
 * Cualquier cambio de filtro o de tamaño devuelve a la página 1 desde el manejador del evento (no desde un Effect).
 * `inicial` define los filtros de la pantalla, por ejemplo { search: '', status: 'all' }.
 */
export function useListFilters<F extends Record<string, string>>(inicial: F) {
  const [filters, setFilters] = useState<F>(inicial);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSizeState] = useState(10);

  const setFilter = <K extends keyof F>(clave: K, valor: F[K]) => {
    setFilters((prev) => ({ ...prev, [clave]: valor }));
    setPage(1);
  };

  const setPageSize = (tamano: number) => {
    setPageSizeState(tamano);
    setPage(1);
  };

  return { filters, setFilter, page, setPage, pageSize, setPageSize };
}
