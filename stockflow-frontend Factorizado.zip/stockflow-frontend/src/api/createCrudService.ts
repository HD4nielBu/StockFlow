import { apiFetch } from './apiClient';

/**
 * G06/G07: CRUD REST genérico. Cada feature lo instancia con su recurso ('/categorias', '/productos');
 * los componentes expresan intenciones (listar, actualizar...) y nunca construyen URLs ni headers.
 * - eliminar: 204 si se eliminó; 409 si el registro tiene dependencias (FK sin CASCADE).
 * - TUpdate es el reemplazo completo (PUT); por defecto coincide con TCreate.
 */
export function createCrudService<T, TCreate, TUpdate = TCreate>(recurso: string) {
  return {
    listar: (signal?: AbortSignal) => apiFetch<T[]>(recurso, { signal }),
    obtenerPorId: (id: number, signal?: AbortSignal) => apiFetch<T>(`${recurso}/${id}`, { signal }),
    crear: (data: TCreate) => apiFetch<T>(recurso, { method: 'POST', body: JSON.stringify(data) }),
    actualizar: (id: number, data: TUpdate) =>
      apiFetch<T>(`${recurso}/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    eliminar: (id: number) => apiFetch<void>(`${recurso}/${id}`, { method: 'DELETE' }),
  };
}
